import React, { useState, useEffect } from 'react';
import { Search, ChevronLeft, ChevronRight, Info, Database as DbIcon, Loader2, X, GraduationCap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [records, setRecords] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [debugInfo, setDebugInfo] = useState<any>(null);

  const fetchRecords = async (query = '') => {
    setLoading(true);
    try {
      const response = await fetch(`/api/records${query ? `?q=${encodeURIComponent(query)}` : ''}`);
      if (!response.ok) throw new Error('Failed to fetch data');
      const data = await response.json();
      setRecords(data);
      setCurrentIndex(0);
      setError(null);

      if (data.length === 0) {
        const debugRes = await fetch('/api/debug');
        const debugData = await debugRes.json();
        setDebugInfo(debugData);
      } else {
        setDebugInfo(null);
      }
    } catch (err: any) {
      setError(`Error al conectar con la base de datos: ${err.message || 'Error desconocido'}`);
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchRecords(searchQuery);
  };

  const clearSearch = () => {
    setSearchQuery('');
    fetchRecords('');
  };

  const nextRecord = () => {
    if (currentIndex < records.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const prevRecord = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const currentRecord = records[currentIndex];

  // Helper to format field names into "descriptions" (Capitalized and spaced)
  const formatLabel = (key: string) => {
    if (key === '_id') return 'ID Registro';
    return key
      .replace(/_/g, ' ')
      .replace(/([A-Z])/g, ' $1')
      .trim()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  };

  return (
    <div className="min-h-screen bg-[#F0F4F8] text-[#102A43] font-sans selection:bg-[#243B53] selection:text-white">
      {/* Header */}
      <header className="border-b border-[#D9E2EC] bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-6 py-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#243B53] flex items-center justify-center text-white shadow-lg">
              <GraduationCap size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-[#102A43]">Física Sevilla</h1>
              <p className="text-[10px] text-[#486581] uppercase tracking-[0.2em] font-bold mt-0.5">
                Facultad de Física · Universidad de Sevilla
              </p>
            </div>
          </div>

          <form onSubmit={handleSearch} className="relative group flex-1 max-w-sm">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar en registros..."
              className="w-full pl-10 pr-10 py-2.5 bg-[#F0F4F8] border border-[#D9E2EC] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#243B53]/10 focus:border-[#243B53] transition-all text-sm"
            />
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#829AB1]" size={16} />
            {searchQuery && (
              <button
                type="button"
                onClick={clearSearch}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#829AB1] hover:text-[#102A43]"
              >
                <X size={16} />
              </button>
            )}
          </form>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12 flex flex-col items-center">
        <AnimatePresence mode="wait">
          {loading ? (
            <motion.div
              key="loader"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-32 gap-4"
            >
              <Loader2 className="animate-spin text-[#243B53]" size={48} />
              <p className="text-xs font-bold text-[#486581] uppercase tracking-widest">Accediendo a fisica.mdb...</p>
            </motion.div>
          ) : error ? (
            <motion.div
              key="error"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-red-50 border border-red-100 text-red-900 p-8 rounded-2xl flex flex-col items-center gap-4 text-center max-w-md"
            >
              <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600">
                <Info size={24} />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Error de Conexión</h3>
                <p className="text-sm text-red-700/80 leading-relaxed">{error}</p>
                <p className="text-xs mt-4 text-red-900/40 italic">Asegúrate de que 'fisica.mdb' esté en la raíz del proyecto.</p>
              </div>
            </motion.div>
          ) : records.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-32"
            >
              <DbIcon size={64} className="mx-auto text-[#D9E2EC] mb-6" />
              <h3 className="text-xl font-bold text-[#334E68] mb-2">Sin resultados</h3>
              <p className="text-[#627D98]">No se han encontrado registros que coincidan con tu búsqueda.</p>
              
              {debugInfo && (
                <div className="mt-8 p-6 bg-white rounded-2xl border border-[#D9E2EC] text-left max-w-md mx-auto">
                  <h4 className="text-xs font-bold text-[#486581] uppercase tracking-widest mb-4">Información de Diagnóstico:</h4>
                  <pre className="text-[10px] font-mono text-[#243B53] overflow-auto max-h-40">
                    {JSON.stringify(debugInfo, null, 2)}
                  </pre>
                  <p className="mt-4 text-[10px] text-[#829AB1] leading-relaxed">
                    Si ves tablas con 0 filas, es posible que la base de datos esté vacía o en un formato no compatible.
                  </p>
                </div>
              )}

              <button onClick={clearSearch} className="mt-6 text-[#243B53] font-bold text-sm underline underline-offset-4">Ver todos los registros</button>
            </motion.div>
          ) : (
            <div key="content" className="w-full flex flex-col items-center gap-8">
              {/* Navigation Controls */}
              <div className="flex items-center justify-between w-full max-w-2xl px-4">
                <button
                  onClick={prevRecord}
                  disabled={currentIndex === 0}
                  className="p-3 rounded-full bg-white border border-[#D9E2EC] text-[#243B53] disabled:opacity-20 disabled:cursor-not-allowed hover:bg-[#F0F4F8] transition-all shadow-sm"
                >
                  <ChevronLeft size={24} />
                </button>
                
                <div className="text-center">
                  <span className="text-xs font-bold text-[#486581] uppercase tracking-widest">
                    Registro {currentIndex + 1} de {records.length}
                  </span>
                </div>

                <button
                  onClick={nextRecord}
                  disabled={currentIndex === records.length - 1}
                  className="p-3 rounded-full bg-white border border-[#D9E2EC] text-[#243B53] disabled:opacity-20 disabled:cursor-not-allowed hover:bg-[#F0F4F8] transition-all shadow-sm"
                >
                  <ChevronRight size={24} />
                </button>
              </div>

              {/* Record Card */}
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl shadow-[#102A43]/5 border border-[#D9E2EC] overflow-hidden"
              >
                <div className="bg-[#243B53] px-10 py-6 text-white flex justify-between items-center">
                  <h2 className="text-lg font-bold tracking-tight">Detalles del Registro</h2>
                  <div className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-mono uppercase tracking-wider">
                    FIS-SEC-{String(currentRecord._id).padStart(4, '0')}
                  </div>
                </div>
                
                <div className="p-10 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                  {Object.entries(currentRecord).map(([key, value]) => {
                    if (key === '_id') return null;
                    
                    // Handle different value types (Dates, Objects, etc.)
                    let displayValue = '';
                    if (value === null || value === undefined) {
                      displayValue = '';
                    } else if (value instanceof Date) {
                      displayValue = value.toLocaleDateString();
                    } else if (typeof value === 'object') {
                      displayValue = JSON.stringify(value);
                    } else {
                      displayValue = String(value).trim();
                    }

                    const isEmpty = !displayValue || displayValue === 'null' || displayValue === 'undefined';

                    return (
                      <div key={key} className={`group ${displayValue.length > 50 ? 'md:col-span-2' : ''}`}>
                        <label className="block text-[10px] font-bold text-[#829AB1] uppercase tracking-[0.15em] mb-1.5 group-hover:text-[#243B53] transition-colors">
                          {formatLabel(key)}
                        </label>
                        <div className={`text-sm text-[#102A43] font-medium leading-relaxed bg-[#F0F4F8]/30 p-3 rounded-lg border border-transparent group-hover:border-[#D9E2EC] group-hover:bg-white transition-all min-h-[44px] flex items-center ${isEmpty ? 'bg-transparent border-dashed border-[#D9E2EC]' : ''}`}>
                          {isEmpty ? (
                            <span className="text-[#BCCCDC] italic text-xs">Dato no disponible</span>
                          ) : (
                            displayValue
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="max-w-4xl mx-auto px-6 py-12 border-t border-[#D9E2EC] mt-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-[#627D98] text-xs font-bold uppercase tracking-widest">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            Base de Datos: fisica.mdb
          </div>
          <p>© 2026 Facultad de Física · Universidad de Sevilla</p>
        </div>
      </footer>
    </div>
  );
}
